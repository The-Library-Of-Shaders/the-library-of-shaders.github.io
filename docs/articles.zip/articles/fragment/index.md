# Fragment Shaders

Fragment shaders are the shaders that run directly on geometry after vertex shaders usually. They can do a lot of things, such as texturing, fog, and normal map effects.

